<?php

//A continuación se detallan los mensajes que le pueden llegar
// * al controlador y la lógica de proceso para cada uno de ellos.
// * 
// * - Petición Inicial o Proceso de Botón de Nuevo Juego
// *   -- Inicializo el tablero con cadenas vacías
// *   -- Almaceno el tablero en $_SESSION
// *   -- Mostrar la vista "move" para que el jugador empiece a jugar.
// * - Proceso Jugada (Petición hecha por medio de AJAX)
// *   -- Leer la celda seleccionada
// *   -- Modificar el estado del tablero
// *   -- Si hay tres en raya mostrar el mensaje de final partida informando de la victoria del jugador
// *      sino Si hay tablas mostrar el mensaje de tablas informando de las tablas
// *         sino generar la jugada del computador
// *              Modificar el estado del tablero
// *              si hay tres en raya mostrar el mensaje de final partida informando de la victoria del computador
// *              sino  Si hay tablas mostrar el mensaje de tablas informando de las tablas
// *                sino  Almacenar el estado del tablero en la sesión
// *                      devolver el movimiento hecho por el ordenador con la respuesta AJAX


require "vendor/autoload.php";

use eftec\bladeone\BladeOne;

$views = __DIR__ . '\views';
$cache = __DIR__ . '\cache';

$blade = new BladeOne($views, $cache);
$blade->setBaseURL("http://localhost:8080");

const PATH_PLAYER_PIC = "public/assets/img/circle.jpg";
const PATH_COMPUTER_PIC = "public/assets/img/cross.jpeg";
const BOARD_SIZE = 3;

session_start();
if (empty($_POST)) {
    $tablero = array();
    for ($i = 0; $i < BOARD_SIZE; $i++) {
        $tablero[$i] = array();

        for ($k = 0; $k < BOARD_SIZE; $k++) {
            $tablero[$i][$k] = "";
        }
    }
    $_SESSION['tablero'] = $tablero;
    echo $blade->run('move');
} else {
    $xUser = filter_input(INPUT_POST, "x");
    $yUser = filter_input(INPUT_POST, "y");
    $tablero = $_SESSION['tablero'];

    $tablero[$xUser][$yUser] = "O";
    $result = Array();
    $ocupado = false;

    if (tresEnRaya($tablero, "O")) {
        $result['gameRes'] = 1;
    } elseif (!hayEspacio($tablero)) {
        $result['gameRes'] = 0;
    } else {
        if (hayEspacio($tablero)) {
            while (!$ocupado) {
                $xCpu = rand(0, 2);
                $yCpu = rand(0, 2);
                if (empty($tablero[$xCpu][$yCpu])) {
                    $tablero[$xCpu][$yCpu] = "X";
                    $ocupado = true;
                }
            }
        }
    }

    $_SESSION['tablero'] = $tablero;
    if (tresEnRaya($tablero, "X")) {
        $result['gameRes'] = -1;
    }

    if (!isset($result["gameRes"]) || $result['gameRes'] == -1) {
        $result["x"] = $xCpu;
        $result["y"] = $yCpu;
    }

    echo json_encode($result);
}

function hayEspacio($tablero): bool {
    $resultado = false;
    foreach ($tablero as $board) {
        if (in_array("", $board)) {
            $resultado = true;
        }
    }
    return $resultado;
}

function tresEnRaya($tablero, $ficha): bool {
    $enRaya = false;
    for ($i = 0; $i < BOARD_SIZE; $i++) {
        if ($tablero[$i][0] == $ficha && $tablero[$i][1] == $ficha && $tablero[$i][2] == $ficha) {
            $enRaya = true;
        }
        if ($tablero[0][$i] == $ficha && $tablero[1][$i] == $ficha && $tablero[2][$i] == $ficha) {
            $enRaya = true;
        }
    }
    if ($tablero[0][0] == $ficha && $tablero[1][1] == $ficha && $tablero[2][2] == $ficha) {
        $enRaya = true;
    }
    if ($tablero[0][2] == $ficha && $tablero[1][1] == $ficha && $tablero[2][0] == $ficha) {
        $enRaya = true;
    }
    return $enRaya;
}

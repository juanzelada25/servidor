<?php

session_start();
require 'vendor/autoload.php';

use eftec\bladeone\BladeOne;

$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    $_SESSION = [];
    session_destroy();
    echo $blade->run('equipo');
} elseif (!empty($_POST['equipoEnviado'] && isset($_POST['equipoEnviado']))) {
    if (strpos($_POST['equipos'], ' ')) {
        $equipos = explode(' ', $_POST['equipos']);
        $_SESSION['equipos'] = $equipos;
        echo $blade->run('mostrarPartido', ['equipos' => $_SESSION['equipos']]);
    }
}elseif('')
?>


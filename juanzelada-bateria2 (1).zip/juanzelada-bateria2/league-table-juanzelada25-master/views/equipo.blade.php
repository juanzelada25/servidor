$extends('inicio')
@section('contenido')
<form action="index.php" method='POST'  >
    <label>Nombre de los equipos</label>
    <br>
    <input type="text" name="equipos" placeholder='Minimo Dos Equipos' />
    <br>
    <input type='submit' value="enviar" name="equipoEnviado">
</form>

@endsection


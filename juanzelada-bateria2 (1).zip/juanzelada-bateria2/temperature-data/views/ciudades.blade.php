@extends('inicio')
@section('titulo','Ciudades')
@section('contenido')
<form action="index.php" method="POST">
    <label>Inserte Ciudad</label>
    <br>
    <input type='text' name='ciudad'/>
    <br>
    <input type='submit' name='enviarCiudades'>
</form>
@endsection


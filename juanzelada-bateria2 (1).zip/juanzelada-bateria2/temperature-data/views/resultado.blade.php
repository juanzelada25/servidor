@extends('inicio')

@section('contenido')

<h1>Resumen Anual de Temperaturas</h1>

<table border="1">
    <thead>
        <tr>
            <th>Ciudad</th>
            <th>Temperatura Máxima</th>
            <th>Temperatura Mínima</th>
            <th>Media Anual</th>
        </tr>
    </thead>
    <tbody>
        @foreach($array as $ciudad => $meses)
            @php
                $maxima = -INF; // Valor inicial muy bajo
                $minima = INF;  // Valor inicial muy alto
                $suma = 0;      // Para sumar las medias mensuales
                $contador = 0;  // Contar los meses

                foreach ($meses as $temperatura) {
                    // Actualiza la temperatura máxima
                    if ($temperatura['max'] > $maxima) {
                        $maxima = $temperatura['max'];
                    }
                    // Actualiza la temperatura mínima
                    if ($temperatura['min'] < $minima) {
                        $minima = $temperatura['min'];
                    }
                    // Calcula la suma de las medias mensuales
                    $suma += ($temperatura['min'] + $temperatura['max']) / 2;
                    $contador++;
                }

                // Calcula la media anual
                $media = $contador > 0 ? $suma / $contador : 0;
            @endphp
            <tr>
                <td>{{ $ciudad }}</td>
                <td>{{ $maxima }}</td>
                <td>{{ $minima }}</td>
                <td>{{ number_format($media, 2) }}</td>
            </tr>
        @endforeach
    </tbody>
</table>
<br>
<a href="http://localhost:8080/index.php">Reiniciar Temperatura</a>


@endsection



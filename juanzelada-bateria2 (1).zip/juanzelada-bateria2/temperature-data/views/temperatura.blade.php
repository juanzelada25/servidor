@extends('inicio')
@section('contenido')

<form action="index.php" method="POST">
    @foreach($ciudades as $ciudad)
    <table>
        <label>{{$ciudad}}</label>
        <br>
        <tr>
            <td rowspan="2">Enero</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][0][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][0][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Febrero</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][1][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][1][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Marzo</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][2][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][2][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Abril</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][3][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][3][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Mayo</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][4][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][4][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Junio</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][5][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][5][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Julio</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][6][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][6][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Agosto</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][7][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][7][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Septiembre</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][8][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][8][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Octubre</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][9][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][9][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Noviembre</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][10][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][10][max]" placeholder="max" /></td>
        </tr>
        <tr>
            <td rowspan="2">Diciembre</td>
            <td><input type="text" name="temperatura[{{$ciudad}}][11][min]" placeholder="min" /></td>
        </tr>
        <tr>
            <td><input type="text" name="temperatura[{{$ciudad}}][11][max]" placeholder="max" /></td>
        </tr>
    </table>
    @endforeach
    <br>
    <input type="submit" name="enviarTemperatura" value="Guardar Temperaturas" />
</form>

@endsection



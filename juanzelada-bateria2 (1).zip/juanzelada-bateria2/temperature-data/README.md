# temperature-data
*Escribe un programa PHP que permita al usuario introducir los nombres de varias
cuidades y muestre al usuario una tabla por cada ciudad donde se puedan
introducir las temperaturas máximas y mínimas de todos los meses del 
año. La aplicación consolidará la información mensual en información anual
y mostrará en otra página una única tabla en la que las filas representan cada ciudad
y las columnas serán las temperaturas mínimas. máximas y medias anuales de cada ciudad.
ordenadas por los criterios de temperatura máxima descendente, mínima ascendente
y finalmente alfabéticamente.*


1. Arrays n-dimensionales
2. Estructuras de control de recorrido de arrays
3. Construcción de condiciones lógicas
4. Ordenación de arrays. multisort
5. Envío de bloques de información compacta desde el formulario
6. Uso de composer
7. Generación de vistas con motor de vistas BladeOne
8. Arquitectura controlador y vistas. Patrón MVC


<?php

session_start();
require 'vendor/autoload.php';

use eftec\bladeone\BladeOne;

$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    $_SESSION = [];
    session_destroy();
    echo $blade->run('ciudades');
} else if (isset($_POST['enviarCiudades'])) {
    $ciudades = filter_input(INPUT_POST, 'ciudad');
    $_SESSION['temperatura'] = [];
    $array_ciudades = explode(' ', $ciudades);
    $meses = array_fill(0, 12, null);
    $temp = ["min" => null, "max" => null];
    foreach ($array_ciudades as $ciudad) {
        if (!isset($_SESSION['temperatura'][$ciudad])) {
            foreach ($meses as $mes) {
                $_SESSION['temperatura'][$ciudad][$mes] = $temp;
            }
        }
    }
    echo $blade->run('temperatura', ['ciudades' => $array_ciudades]);
}else if (isset($_POST['enviarTemperatura'])) {
    if (isset($_POST['temperatura'])) {
        // Guardar las temperaturas en la sesión
        foreach ($_POST['temperatura'] as $ciudad => $meses) {
            foreach ($meses as $mes => $temperaturas) {
                $min = $temperaturas['min'];
                $max = $temperaturas['max'];

                $_SESSION['temperatura'][$ciudad][$mes] = [
                    'min' => $min,
                    'max' => $max
                ];
            }
        }

        // Preparamos los datos para ordenar
        $maximas = [];
        $minimas = [];
        $nombres = [];

        foreach ($_SESSION['temperatura'] as $ciudad => $meses) {
            // Encontramos la temperatura máxima y mínima de cada ciudad
            $maxima = 0; // Valor inicial muy bajo
            $minima = 0;  // Valor inicial muy alto
            foreach ($meses as $temperatura) {
                $maxima = max($maxima, $temperatura['max']);
                $minima = min($minima, $temperatura['min']);
            }

            // Guardamos la temperatura máxima, mínima y el nombre de la ciudad
            $maximas[] = $maxima;
            $minimas[] = $minima;
            $nombres[] = $ciudad;
        }

        // Ordenamos primero por temperatura máxima descendente, luego mínima ascendente y al final alfabéticamente
        array_multisort($maximas, SORT_DESC, $minimas, SORT_ASC, $nombres, SORT_ASC, $_SESSION['temperatura']);

        // Pasamos los datos a la vista
        echo $blade->run('resultado', ['array' => $_SESSION['temperatura']]);
    }
}



?>
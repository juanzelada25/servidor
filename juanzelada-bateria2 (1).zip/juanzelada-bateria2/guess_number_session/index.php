<?php

require 'vendor/autoload.php';
session_start();

use eftec\bladeone\BladeOne;

$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    $_SESSION = [];
    session_destroy();
    echo $blade->run("inicio");
} else {
    if (!isset($_SESSION['numeroSuperior']) || !isset($_SESSION['numeroInferior']) || !isset($_SESSION['vida']) || empty($_SESSION['vida']) || empty($_SESSION['numeroInferior'])|| $_SESSION['vida'] < 1 || $_SESSION['numeroSuperior'] < $_SESSION['numeroInferior']) {
        $_SESSION['numeroSuperior'] = filter_input(INPUT_POST, 'superior');
        $_SESSION['numeroInferior'] = filter_input(INPUT_POST, 'inferior');
        $_SESSION['vida'] = filter_input(INPUT_POST, 'vida');
        if (!isset($_SESSION['numeroSuperior']) || !isset($_SESSION['numeroInferior']) || empty($_SESSION['vida']) || empty($_SESSION['numeroInferior']) || empty($_SESSION['vida']) || $_SESSION['vida'] < 1 || $_SESSION['numeroSuperior'] < $_SESSION['numeroInferior']) {
            echo $blade->run('inicio');
        } else {
            $_SESSION['random'] = rand($_SESSION['numeroInferior'], $_SESSION['numeroSuperior']);
            echo $blade->run('numero');
        }
    } else {
        if (!isset($_SESSION['insertado']) || empty($_SESSION['insertado'])) {
            $_SESSION['insertado'] = filter_input(INPUT_POST, 'numeroInsertado');
            if (!isset($_SESSION['insertado']) || empty($_SESSION['insertado'])) {
                echo $blade->run('numero');
            } else {
                if ($_SESSION['insertado'] > $_SESSION['random'] && $_SESSION['vida'] > 0) {
                    $_SESSION['vida']--;
                    if ($_SESSION['vida'] > 0) {
                        $mensaje = "El numero es menor te quedan " . $_SESSION['vida'] . "vida";
                        $_SESSION['insertado'] = null;
                        echo $blade->run('numero', ['mensaje' => $mensaje]);
                    } else {
                        $mensaje = "Ya no te quedan vidas disponibles";
                        echo $blade->run('fallido', ['mensaje' => $mensaje]);
                    }
                } elseif ($_SESSION['insertado'] < $_SESSION['random'] && $_SESSION['vida'] > 0) {
                    $_SESSION['vida']--;
                    if ($_SESSION['vida'] > 0) {
                        $mensaje = "El numero es mayor te quedan " . $_SESSION['vida'] . "vida";
                        $_SESSION['insertado'] = null;
                        echo $blade->run('numero', ['mensaje' => $mensaje]);
                    } else {
                        $mensaje = "Ya no te quedan vidas disponibles";
                        echo $blade->run('fallido', ['mensaje' => $mensaje]);
                    }
                } else {
                    $num = $_SESSION['insertado'];
                    $mensaje = "el numero es " . $num;
                    echo $blade->run('correcto', ["mensaje" => $mensaje]);
                }
            }
        }
    }
}
?>
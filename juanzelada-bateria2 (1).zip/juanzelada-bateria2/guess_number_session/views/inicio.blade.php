@extends('intento')  <!-- Extiende la plantilla base -->

@section('title', 'Bienvenido al Juego')  <!-- Título de la página -->

@section('content')
<h2>¡Bienvenido al juego!</h2>
<p>El objetivo es adivinar el número secreto.</p>
<form action="index.php" method="POST">
    <label for="superior">Número Superior:</label>
    <input type="number" name="superior">
    <br>
    <label for="inferior">Número Inferior:</label>
    <input type="number" name="inferior">
    <br>
    <label for="vidas">Vidas:</label>
    <input type="number" name="vida">
    <br>
    <input type="submit" value="Enviar">
</form>
@endsection

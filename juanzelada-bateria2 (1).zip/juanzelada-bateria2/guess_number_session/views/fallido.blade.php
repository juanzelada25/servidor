@extends('intento')  <!-- Extiende de la plantilla base -->

@section('title', 'Jugar de nuevo')  <!-- Título personalizado -->

@section('content')
<h2>¡Has agotado todos tus intentos!</h2>
<form action="index.php" method="GET">
    <button name="reiniciar">Jugar de nuevo</button>
</form>
@endsection


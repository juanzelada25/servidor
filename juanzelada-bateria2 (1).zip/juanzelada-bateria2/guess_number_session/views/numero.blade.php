@extends("intento")
@section("content")
<p>{{$mensaje}}<p>
<form action="index.php" method="POST">
    <label>Inserta el numero</label>
    <br>
    <input type="number" name="numeroInsertado"/>
    <br>
    <input type="submit" value="enviar">
</form>

@endsection

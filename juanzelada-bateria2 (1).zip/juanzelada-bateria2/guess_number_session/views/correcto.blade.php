@extends('intento')  <!-- Extiende de la plantilla base -->

@section('title', '¡Felicidades!')  <!-- Título personalizado -->

@section('content')
<h2>¡Felicidades!</h2>
<p>¡Has adivinado el número correctamente! </p>
<p>Es {{$mensaje}}</p>

<form action="index.php" method="GET">
    <button name="reiniciar">Jugar de nuevo</button>
</form>
@endsection


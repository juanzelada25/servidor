<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <title>User mgmt</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="public/css/stylesheet.css">
    </head>

    <body>
        <header>
            <h1>User-mgmt</h1>
        </header>

        @yield('content')
    </body>
</html>

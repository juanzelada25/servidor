<?php
$nombre = htmlspecialchars($_POST['nombre']);
$contrasenia = htmlspecialchars($_POST['contrasenia']);
$email = htmlspecialchars($_POST['email']);
$fechanac = htmlspecialchars($_POST['fecha']);
$telefono = htmlspecialchars($_POST['tel']);
$nomtienda = htmlspecialchars($_POST['poblacion']);
$edad = htmlspecialchars($_POST['edad']);
$suscripcion = htmlspecialchars($_POST['suscripcion']);
?>
<html>
    <head>
        <meta charset = "UTF-8">
        <meta name=" viewport" content="width=device-width, initial-scale=1,0">
        <link rel="stylesheet" href="estilo.css">
    </head>
    <body>
        <h1 class="info"> Informacion de datos enviados</h1>
        <h3>Nombre: <?php echo $nombre; ?> </h3>
        <h3>Contraseña: <?php echo $contrasenia; ?> </h3>
        <h3>Email: <?php echo $email; ?> </h3>
        <h3>Fecha de nacimiento: <?php echo $fechanac; ?> </h3>
        <h3>Telefono: <?php echo $telefono; ?>  </h3>
        <h3>Nombre de la tienda: <?php echo $nomtienda; ?> </h3>
        <h3>Edad: <?php echo $edad; ?> </h3>
        <h3>Suscripcion: <?php echo $suscripcion; ?> </h3>
    </body>

</html>







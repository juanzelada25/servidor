# read-and-show-values-from-form
*Escribe un programa PHP que permita al usuario rellenar un formulario de registro con los datos de nombre, contraseña, fecha de nacimiento, telefono, tienda, edad y suscripción. El programa recibe los datos del formulario y los muestra en pantalla tal y como los escribió el usuario. En el caso en que el campo se haya dejado vacío se informará que no se han introducido datos*

Conocimientos:

1. Procedimiento de paso de parámetros entre formulario y script PHP

2. Creación de una página web con código embebido


<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Título de la Página</title>
        <link rel="stylesheet" href="estilo.css"> <!-- Enlace a la hoja de estilos CSS -->
    </head>
    <body>
        <form action="index.php" method="post">
            <div id="datos">
                <label for="numero">Numero</label>
                <input type="number" id="numero" name="numero">
            </div>
        </form>
    </body>
</html>
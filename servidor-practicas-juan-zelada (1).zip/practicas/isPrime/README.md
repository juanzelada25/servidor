# is-prime
*Escribe un programa PHP que permita al usuario introducir un número e informe al usuario de si se trata de un número primo o no.*

Conocimientos:

1. Estructura de control iterativo


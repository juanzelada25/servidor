<?php
$errores = [];
$primo = true;
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $errores[] = "error al enviar los datos";
} else {
    $numero = filter_input(INPUT_POST, 'numero');
    if (empty($numero)) {
        $errores[] = "el numero no puede estar vacio";
    }

    if ($numero <= 1) {
        $primo = false;
    } else {
        $i = 2;
        while ($i < $numero) {
            if ($numero % $i == 0) {
                $primo = false;
                break;
            }
            $i++;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="estilo.css"> <!-- Enlace a la hoja de estilos CSS -->
    </head>
    <body>
        <form action="index.php" method="post">
            <div id="datos">
                <h1 id="titulo"> ES PRIMO</h1>
                <label for="numero">Numero</label>
                <input type="number" id="numero" name="numero">
                <input type="submit" id = "enviar" name="enviar">
            </div>
        </form>
    </body>         
</html>
<?php
if (isset($numero)) {
    if (!empty($errores)) {
        foreach ($errores as $error) {
            echo "$error";
        }
    } else {
        if ($primo) {
            echo "el numero es primo";
        } else {
            echo "el numero no es primo";
        }
    }
}
?>
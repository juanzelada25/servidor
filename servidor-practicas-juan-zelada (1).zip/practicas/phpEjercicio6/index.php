<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Tablas de Multiplicar</title>
        <link rel="stylesheet" href="estilo.css"/>
    </head>
    <body>

        <h1>Tablas de Multiplicar</h1>

        <form method="post" action="index.php">
            <label for="numeros">Introduce números (1-9 separados por comas o guiones):</label><br>
            <input type="text" id="numeros" name="numeros" required>
            <br><br>
            <input type="submit" value="Generar tablas">
        </form>

        <?php

// Función para procesar la cadena de entrada y obtener un array de números únicos
        function obtenerNumeros($entrada) {
            $resultado = [];

            // Verificamos si el formato es correcto
            if (preg_match('/^([1-9](\-[1-9])?)(,[1-9](\-[1-9])?)*$/', $entrada)) {
                // Dividimos la cadena por comas
                $elementos = explode(',', $entrada);

                foreach ($elementos as $elemento) {
                    // Si el elemento es un rango (contiene un guión)
                    if (strpos($elemento, '-') !== false) {
                        list($inicio, $fin) = explode('-', $elemento);
                        $inicio = (int) $inicio;
                        $fin = (int) $fin;
                        // Agregamos todos los números del rango al array
                        $resultado = array_merge($resultado, range($inicio, $fin));
                    } else {
                        // Si no es un rango, lo convertimos a entero
                        $resultado[] = (int) $elemento;
                    }
                }

                // Eliminamos duplicados y ordenamos el array
                $resultado = array_unique($resultado);
                sort($resultado);
            } else {
                // Si el formato es incorrecto, mostramos un mensaje de error
                echo "<p style='color:red;'>Formato de entrada inválido. Introduce números del 1 al 9, separados por comas o guiones para rangos.</p>";
                return null;
            }

            return $resultado;
        }

// Función para generar una tabla de multiplicar en HTML
        function mostrarTablaMultiplicar($numero, $colorClase) {
            echo "<table class='$colorClase'>";
            echo "<thead><tr><th colspan='2'>Tabla del $numero</th></tr></thead>";
            echo "<tbody>";
            for ($i = 1; $i <= 10; $i++) {
                echo "<tr>";
                echo "<td>$numero x $i</td>";
                echo "<td>" . ($numero * $i) . "</td>";
                echo "</tr>";
            }
            echo "</tbody></table>";
        }

// Procesamos el formulario si se ha enviado
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $entrada = $_POST['numeros'];

            // Obtenemos los números validados
            $numeros = obtenerNumeros($entrada);

            if ($numeros !== null) {
                // Mostramos las tablas de multiplicar con colores alternados
                $colorAlternado = false;
                foreach ($numeros as $numero) {
                    $claseColor = $colorAlternado ? 'gris' : '';
                    mostrarTablaMultiplicar($numero, $claseColor);
                    $colorAlternado = !$colorAlternado; // Alternar color
                }
            }
        }
        ?>

    </body>
</html>


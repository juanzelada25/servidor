<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit();
}
//patrones que cumple
$errorPass = "/^[a-z A-Z 0-9]{6,8}$/";
$errorNom = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\s)[a-zA-Z\s]{3,25}$/";
$errorTel = "/^[0-9]{9}$/";
//variables recogidas
$name = filter_input(INPUT_POST, 'name');
$password = filter_input(INPUT_POST, 'password');
$email = filter_input(INPUT_POST, 'email');
$date = filter_input(INPUT_POST, 'dateofbirth');
$tel = filter_input(INPUT_POST, 'tel');
$shop = filter_input(INPUT_POST, 'shop');
$age = filter_input(INPUT_POST, 'age');
$suscripcion = filter_input(INPUT_POST, 'subscription');
// comprobacion de si lo demas es correcto 
$emailSI = filter_var($email, FILTER_VALIDATE_EMAIL);
$telefonoSI = filter_var($tel, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => $errorTel)));
$nombreSI = filter_var($name, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => $errorNom)));
$contraSI = filter_var($name, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => $errorPass)));
$camposVacios = empty($name) || empty($password) || empty($email) || empty($date) || empty($tel) || empty($shop) || empty($age) || empty($suscripcion);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Register Form</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" href="stylesheet.css">
    </head>
    <body>
        <div class="flex-page">
            <h1>Customer Registration</h1>
            <form class="form-font capaform" name="registerform" 
                  action="procesoformulario.php" method="POST">
                <div class="flex-outer">
                    <div class="form-section">
                        <label for="name">Name:</label> 
                        <input id="name" type="text" name="name" placeholder="Enter your name:"/> 
                        <?php if (empty($name)): ?>
                            <p style="color: red;"> El nombre no puede estar vacio </p>  
                        <?php elseif (!$nombreSI): ?> 
                            <p style="color: red;"> El nombre debe contener letras mayúsculas y minúsculas y espacios, con una longitud de 3 a 25 caracteres.</p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <label for="password">Contraseña:</Label> 
                        <input id="password" type="password" name="password" placeholder="Enter your password:"/> 
                        <?php if (empty($password)): ?>
                            <p style="color:  red;"> La contraseña no puede estar vacia</p>
                        <?php elseif ($contraSI): ?>
                            <p style="color: red;">La contraseña debe tener entre 6 y 8 caracteres alfanuméricos.</p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <label for="email">Email:</Label> 
                        <input id="email" type="text"  name="email" placeholder="Enter your email">
                        <?php if (empty($email)): ?>
                            <p style="color: red;"> El email no puede estar vacio  </p>
                        <?php elseif (!$emailSI): ?>
                            <p style="color: red;">  El email no es correcto </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <label for="dateofbirth">Date of Birth:</Label> 
                        <input id="dateofbirth" type="date" name="dateofbirth" placeholder="Enter your date of birth">
                        <?php if (empty($date)): ?>
                            <p style="color: red;"> La fecha no puede estar vacio</p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <label for="telephone">Telefono Móvil:</Label> 
                        <input id="telephone" type="tel" name="tel" placeholder="Enter your telephone">
                        <?php if (empty($tel)): ?>
                            <p style="color: red;">El movil no puede estar vacio</p>
                        <?php elseif (!$telefonoSI): ?>
                            <p style="color: red;">El telefono  no esta correctamente introducido </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <label for="shop">Closest Shop:</Label> 
                        <select id="shop" name="shop">
                            <option value="Madrid">Madrid</option>
                            <option value="Barcelona">Barcelona</option>
                            <option value="Valencia">Valencia</option>
                        </select>
                        <?php if (empty($shop)): ?>
                            <p style= " color:red;"> La tienda no puede estar vacia</p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <label>Age:</label>
                        <div class="select-section">
                            <div>
                                <input id="-25" type="radio" name="age" value="-25" /> 
                                <label for="-25">Younger than 25</label>
                            </div>
                            <div>
                                <input id="25-50" type="radio" name="age" value="25-50" /> 
                                <label for="25-50">Between 25 and 50</label>
                            </div>
                            <div>
                                <input id="50-" type="radio" name="age" value="50-" />
                                <label for="50-">Older than 50</label>
                            </div>
                            <?php if (empty($age)): ?>
                                <p style="color: red;"> La edad es obligatoria </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-section">
                        <label for="subscription">Newsletter subscription:</label>
                        <input id="subscription" type="checkbox"  name="subscription"/> 
                        <?php if (empty($suscripcion)): ?>
                            <p style="color:red;"> No suscrito </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-section">
                        <div class="submit-section">
                            <input class="submit" type="submit" 
                                   value="Send" name="sendbutton" /> 
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </body>
</html>
<?php if (!empty($_POST) && !$camposVacios && $telefonoSI && $emailSI&& $nombreSI && $contraSI): ?>
    <div class="flex-page">
        <h1>Datos introducidos</h1>
        <div class="form-font capaform">
            <?php
            echo "Nombre: " . htmlspecialchars($name) . "<br><br>";
            echo "Contraseña: " . htmlspecialchars($password) . "<br><br>";
            echo "Email: " . htmlspecialchars($email) . "<br><br>";
            echo "Fecha de nacimiento: " . htmlspecialchars($date) . "<br><br>";
            echo "Telefono: " . htmlspecialchars($tel) . "<br><br>";
            echo "Suscrito: " . ($suscripcion ? "Sí" : "No") . "<br><br>";
            echo "Tienda: " . htmlspecialchars($shop) . "<br><br>";
            echo "Edad: " . htmlspecialchars($age) . "<br><br>";
            ?>
        </div>
    </div>
<?php endif; ?>

# guess-a-number
*Desarrolla un juego en el que el jugador puede realizar cinco intentos para descubrir un número oculto del 1 al 10. 
El juego comienza y el jugador va introduciendo una a una sus apuestas. 
Después de cada apuesta, la aplicación le devuelve al jugador un mensaje informando del resultado de la jugada. Si la 
jugada no es certera, la aplicación informará al jugador de si su número  es superior 
o inferior al número secreto. El juego acaba cuando el jugador acierta el número o 
llega al máximo de intentos. Una vez terminado el juego la aplicación permitirá al jugador iniciar un nuevo juego*

Orientaciones:

1. Generación de números aleatorios

2. Estructura de control condicional
3. Estructura de control repetitiva

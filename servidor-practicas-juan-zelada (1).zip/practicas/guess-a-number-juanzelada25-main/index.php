<?php
$num = 0;
$errores = [];
$random = filter_input(INPUT_POST, 'random', FILTER_VALIDATE_INT) ?? rand(1, 10);
$intentos = filter_input(INPUT_POST, 'intentos', FILTER_VALIDATE_INT) ?? 5;
$estado = false;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $errores[] = "Envio de datos incorrectos";
} else {
    $num = filter_input(INPUT_POST, 'num', FILTER_VALIDATE_INT);
    if (empty($num)) {
        $errores[] = "no se ha escrito ningun numero";
    }
  
    if ($num != $random) {
        if ($num < $random ) {
            $errores [] = "El numero es mayor";
        } else {
            $errores[] = "El numero es menor";
        }
        $intentos--;
    } else {
        $estado = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Adivina el Número</title>
    </head>
    <body>
        <h1>¡Adivina el número entre 1 y 10!</h1>
        <?php if ($estado): ?>
            <p>Felicidades has adivinado el juego</p>
        <?php elseif ($intentos < 1): ?>
            <p>Fallaste ya no te quedan intentos <br> El numero correcto es <?php echo $random ?>  </p>
        <?php else: ?>
            <form action="index.php" method="post">
                <label for="numero">Introduce un número:</label>
                <input type="number" name="num">
                <input type="hidden" name="intentos" value="<?php echo $intentos; ?>">
                <input type="hidden" name="random" value="<?php echo $random; ?>">
                <input type="submit" value="Apostar">
            </form> 
        <?php endif; ?>
        <?php
        if (!empty($errores)) {
            foreach ($errores as $error) {
                echo $error;
            }
        }
        ?>
    </body>
</html>


<?php
// se comprueba de que si es de otro metodo get por ejemplo redirija a la pagina 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    
} else {
//recogemos el dato
    $cantidad = $_POST['cantidad'];
//recogemos la divisa
    $divisaR = $_POST['divisaR'];
//recogemos la divisa a la que queremos convertir por ejemplo USD,EUR,ETC
    $divisaC = $_POST['divisaC'];
    $error = [];
    $tasa;
    $conversion;
    $conversionUnidad;
    if (empty($cantidad)) {
        $error [] = "Tienes que insertar la cantidad";
    }
    if (empty($divisaR)) {
        $error[] = "Tienes que insertar una divisa";
    }
    if (empty($divisaC)) {
        $error [] = "Tienes que seleccionar una divisa a la que convertir";
    }
//primero pregunta que tipo de divisa quiere convertir
//luego ve que tipo es el destino y opera
    if (!empty($cantidad)) {
        if (strtolower($divisaC) == 'eur') {
            switch (strtolower($divisaR)) {
                case "eur":
                    $error[] = "No puedes convertir de euro a euro";
                    break;
                case "usd":
                    $tasa = 1.10;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " €";
                    break;
                case "gbp":
                    $tasa = 0.837;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " €";
                    break;
                case "cny":
                    $tasa = 7.73;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " €";
                    break;
            }
        } else if (strtolower($divisaC) == 'usd') {
            switch (strtolower($divisaR)) {
                case "eur":
                    $tasa = 0.9139;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " '$'";
                    break;
                case "usd":
                    $error [] = "No puedes convertir de dolar a dolar";
                    break;
                case "gbp":
                    $tasa = 0.7653;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " '$'";
                    break;
                case "cny":
                    $tasa = 7.07;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " '$'";
                    break;
            }
        } else if (strtolower($divisaC) == 'gbp') {
            switch (strtolower($divisaR)) {
                case "eur":
                    $tasa = 0.837;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " '£'";
                    break;
                case "usd":
                    $tasa = 0.905;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " '£'";
                    break;
                case "gbp":
                    $error[] = "No puedes convertir de libra esterlina a libra esterlina";
                    break;
                case "cny":
                    $tasa = 9.23554;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . " '£'";
                    break;
            }
        } else if (strtolower($divisaC) == 'cny') {
            switch (strtolower($divisaR)) {
                case "eur":
                    $tasa = 0.1293;
                    $conversion = ($cantidad * $tasa);
                    $conversionUnidad = $conversion . " '¥'";
                    break;
                case "usd":
                    $tasa = 0.1414;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . "'¥'";
                    break;
                case "gbp":
                    $tasa = 0.1082;
                    $conversion = $cantidad * $tasa;
                    $conversionUnidad = $conversion . "'¥'";
                    break;
                case "cny":
                    $error[] = "No puedes convertir de Yuan a Yuan";
                    break;
            }
        }
    } else {
        $error[]="";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Título de la Página</title>
        <link rel="stylesheet" href="styles.css"> <!-- Enlazar a una hoja de estilos CSS -->
    </head>
    <body>
        <form action="index.php" method="POST">
            <p>Conversiones Ejercicio 4</p>
            <div>
                <label for="cantidad">Introduce la cantidad</label>
                <input type="number" name="cantidad">
            </div>

            <div>
                <label for="divisaR">Introduce la divisa origen (Ejemplo USD)</label>
                <select name="divisaR">
                    <option value="EUR">Euros</option>
                    <option value="USD">Dolar</option>
                    <option value="GBP">Libra Esterlina</option>
                    <option value="CNY">Yuan</option>
                </select> 
            </div>

            <div>
                <label for="divisaC">Introduce la divisa destino </label>
                <select name="divisaC">
                    <option value="EUR">Euros</option>
                    <option value="USD">Dolar</option>
                    <option value="GBP">Libra Esterlina</option>
                    <option value="CNY">Yuan</option>
                </select> 
            </div>
            <div>
                <button type="submit">Convertir </button>
            </div>
            <div>
                <?php
                if (!empty($error)) {
                    foreach ($error as $errores) {
                        echo "<p> $errores </p>";
                    }
                }
                if (isset($conversion)) {
                    echo "<p> La cantidad es  $conversionUnidad </p>";
                }
                ?>
            </div>
        </form>
    </body>
</html>
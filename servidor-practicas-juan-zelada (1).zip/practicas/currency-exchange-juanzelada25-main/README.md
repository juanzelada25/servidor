# currency-exchange
*Escribe un programa PHP que permita al usuario introducir una cantidad, 
su divisa y la divisa a la que se quiere convertir. El programa devolverá 
una página con la información relativa a dicha conversión. 
El conversor trabajará con cualquier combinación de las siguientes divisas: 
Euro (EUR), Dólar (USD), Libra Esterlina (GBP) y Yuan (CNY)*


Orientaciones:

* Estructura de control condicional switch

* Expresiones aritméticas


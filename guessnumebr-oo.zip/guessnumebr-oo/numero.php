<?php

class Numero {

    private $min;
    private $max;
    private $secreto;
    
    public function __construct($min, $max) {
        $this->min = $min;
        $this->max = $max;
        $this->secreto = rand($min, $max);
    }

    public function getSecreto() {
        return $this->secreto;
    }
}
?>


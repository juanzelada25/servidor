<?php
session_start(); // Iniciar sesión al principio

require 'vendor/autoload.php';
require 'numero.php';

use eftec\bladeone\BladeOne;

$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_AUTO);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Si se presiona el botón de reiniciar, destruimos la sesión
    if (isset($_POST['eliminar'])) {
        session_destroy(); // Eliminar sesión
        $_SESSION = []; // Limpiar la sesión
        echo $blade->run('datos'); // Mostrar el formulario inicial
    } else {
        // Si el formulario 'datos' fue enviado, configuramos las variables de sesión
        if (isset($_POST['datos'])) {
            // Guardamos los valores del formulario en variables
            $min = $_POST['minimo'];
            $max = $_POST['maximo'];
            $vidas = $_POST['vida']; // Número de vidas

            // Inicializamos las variables de sesión
            $_SESSION['vida'] = $vidas; // Guardamos el número de vidas
            $_SESSION['min'] = $min; // Guardamos el valor mínimo
            $_SESSION['max'] = $max; // Guardamos el valor máximo

            // Creamos la clase para obtener el número secreto
            $clase = new numero($min, $max);
            $_SESSION['secreto'] = $clase->getSecreto(); // Guardamos el número secreto

            // Mostramos el formulario para adivinar
            echo $blade->run('intento', ['vida' => $_SESSION['vida']]);
        } 
        // Si se ha enviado un intento y hay vidas restantes
        else if (isset($_POST['intento']) && $_SESSION['vida'] > 0) {
            $insertado = $_POST['insertado']; // El número insertado

            // Verificamos si el número insertado es el correcto
            if ($_SESSION['secreto'] == $insertado) {
                echo "Felicidades, has ganado el juego. ¿Quieres reiniciar?
                      <form method='POST' action=''>
                          <button type='submit' name='eliminar' value='true'>Reiniciar</button>
                      </form>";
            } else {
                // Restamos una vida
                $_SESSION['vida']--;

                if ($insertado > $_SESSION['secreto']) {
                    echo "El número es menor.";
                } else {
                    echo "El número es mayor.";
                }

                // Si aún hay vidas restantes, mostramos el formulario de intento nuevamente
                if ($_SESSION['vida'] > 0) {
                    echo $blade->run('intento', ['vida' => $_SESSION['vida']]);
                } else {
                    // Si se han agotado las vidas, mostramos el mensaje de pérdida
                    echo "Has perdido. ¿Quieres reiniciar?
                          <form method='POST' action=''>
                              <button type='submit' name='eliminar' value='true'>Reiniciar</button>
                          </form>";
                }
            }
        }
    }
} else {
    // Si no se ha enviado ningún formulario, mostramos el formulario inicial
    echo $blade->run('datos');
}
?>




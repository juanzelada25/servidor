@extends('inicio')
@section('contenido')
<h1>Te quedan {{$vida}} Vidas</h1>
<form action="index.php" method="POST">
    <label>Introduce el intento</label>
    <br>
    <input type='number' name="insertado">
    <br>
    <input type="submit" name='intento'>
</form>
@endsection

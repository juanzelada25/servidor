@extends('inicio')
@section('contenido')
<form action="index.php" method="POST">
    <label>Inserte numero minimo<input type="number" min="1" name="minimo" required/></label>
    <br>
    <label>Inserte numero maximo<input type="number" min="1"  name="maximo" required/></label>
    <br>
    <label>numero de vida<input type="number" min="1"  name="vida" required/></label>
    <input type="submit"  name="datos"/>
</form>

@endsection

